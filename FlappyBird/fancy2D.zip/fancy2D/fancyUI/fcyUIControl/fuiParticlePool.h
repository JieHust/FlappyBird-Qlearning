////////////////////////////////////////////////////////////////////////////////
/// @file  fuiParticlePool.h
/// @brief fancyUI ���ӳ�
////////////////////////////////////////////////////////////////////////////////
#pragma once
#include "../fcyUIBase/fuiControl.h"

////////////////////////////////////////////////////////////////////////////////
/// @brief UI ���ӳ�
////////////////////////////////////////////////////////////////////////////////
class fuiParticlePool :
	public fuiControl
{
protected:
	fcyRefPointer<f2dParticlePool> m_pParticlePool;
protected: // ����
	fuiPropertyAccessor<void*> m_ParticlePool_Accessor;
public: // ʵ�ֽӿ�
	void Update(fDouble ElapsedTime);
	void Render(fuiGraphics* pGraph);
public:
	fuiParticlePool(fuiPage* pRootPage, const std::wstring& Name);
	~fuiParticlePool();
};
